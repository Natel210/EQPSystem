#pragma once

#ifdef CORE_DLL_EXPORTS
#define DLL_API __declspec(dllexport)

111
#else
#define DLL_API __declspec(dllimport)
#endif
