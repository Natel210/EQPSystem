#pragma once
class IMain
{
public:
	IMain() {}
	~IMain() {}

private:

};

